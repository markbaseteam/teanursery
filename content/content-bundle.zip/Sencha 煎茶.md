---
title: Sencha 煎茶
tags: tea
date: 2022-08-10
hour: 20:18
---

Status: 🌱

Sencha 煎茶 is the most common tea produced in Japan. It is generally an unshaded tea. If shaded, it is categorised as [[Kabusecha 被せ煎茶・被せ茶]]. The terms 露地煎茶 (ろじ煎茶)(roadside Sencha) and 純煎茶(じゅん煎茶) (pure Sencha) are also used for unshaded sencha, helping with the division between shaded and unshaded sencha. For both, harvesting is usually machine harvested. Harvest season is usually spring and Summer.

The process to make Sencha was developed in Japan by Nagatani Soen in 1738. Who took the Tencha processing techniques of the time, which involved steaming the leaves. Then press and roll the leaves and heat to dry them, creating whole-leaf tea. Farmers at that time were trying to reproduce loose-leaf teas introduced from China.

At that time, the pan-firing method, which developed a brown drink, was the most common processing method. Instead, the Sencha presented a green liquor and was highly valued. The only tea with a similar colour at the time was Matcha. Gyokuro tea production didn't develop until 1835. Sencha was a highly valued tea, only surpassed by Matcha.

The first character in Sencha, 煎 gives us a few indications of some of its characteristics. It translates in multiple ways, such as boil, roast, parch and broil.

Loose-leaf tea from China was introduced to Japan, mainly through monks returning or coming to Japan. At that time, the consumption was trough powder form, but different than the modern Matcha production. It was known as Dancha 団茶. Sencha was the first Japanese-produced tea developed for consumption as a loose-leaf. It was called simmered tea, similar to the traditional Chinese steeping methods. And could also be boiled. Thus the use of that character in its name. 

Another hint to its origin is under the other meaning for 煎, parched or roasted. Pan-firing methods to stop oxidation were the most common practice in China traditionally. The name 煎ったお茶 (いったお茶) translates as roasted tea, which was at some point. Pan-firing was the inherited method in Japan at the beginning. And are still the traditional regional method in southern Japan. 

Now, Sencha is processed almost exclusively via [[Steamed processed teas 蒸し製]] techniques. If there is a variation, it gets categorised under a different name.

A brewed sencha cup should be 金色透明 (きんしょくとうめい), golden in colour and clear. But as a Japanese green tea, bright green colours are also desirable. Sencha can be, sometimes shaded, or the steaming more pronounced, to achieve deep bright green colours like the ones in [[Gyokuro 玉露茶]] or other [[Shaded teas 覆下栽培]].

---
# References
Suzuki, Simona. _Japanese Tea: A Comprehensive Guide_. 2017, pp. 30–31.

Sōsen, Tyas. _The Story of Japanese Tea: A Broad Outline of Its Cultivation, Manufacturing, History and Cultural Values_. 2019.

Association, Global Japanese Tea. “Sencha.” _YouTube_, Video, 12 July 2022, https://youtu.be/SXlz5fg1RKU.

Florent. “The Edo Period: Changes and the Invention of Sencha.” _Japanese Tea Sommelier_, 18 Dec. 2014, https://japaneseteasommelier.wordpress.com/2014/12/18/997/.

全国茶生産団体連合会 (National Association of Tea Producers). “Tea Types and Production Areas.” _Zennoh_, 2019, https://www.zennoh.or.jp/bu/nousan/tea/dekiru03.htm.

農林水産省(Ministry of Agriculture, Forestry and Fisheries). _Current Outlook of Japanese Tea_. 農林水産省(Ministry of Agriculture, Forestry and Fisheries), Dec. 2020, p. 4, https://www.maff.go.jp/j/seisan/tokusan/cha/attach/pdf/ocha-48.pdf.


[[Japanese Tea - A comprehensive guide]]
[[The Story of Japanese Tea]]

---
Tags:
Type: #idea
Zettelkasten UID: 202208102018
