---
title: Kamairicha 釜炒り茶

description: Kamairicha 釜炒り茶 is composed of Kama 釜 (iron pot, pan, cauldron) and 炒り (fry, roast, parch). Can be seen labelled as Kamaguri 釜ぐり or 釜ぐり茶.

canonical: https://teanursery.com
ogUrl: https://teanursery.com
ogTitle: Kamairicha 釜炒り茶 

ogDescription: Kamairicha 釜炒り茶 is composed of Kama 釜 (iron pot, pan, cauldron) and 炒り (fry, roast, parch). Can be seen labelled as Kamaguri 釜ぐり or 釜ぐり茶.

ogImage: https://image-link.xyz
ogSitename: Tea Nursery Notes


title: Kamairicha 釜炒り茶
tags: tea
date: 2022-08-07
hour: 19:40
---
Status: 🪴

## Definition
The two main ways to stop oxidation (kill-green) in teas are pan-firing or steaming the leaves, creating a division on processing for teas in the post-harvest phase.

Kamairicha 釜炒り茶 is composed of Kama 釜 (iron pot, pan, cauldron) and 炒り (fry, roast, parch). Can be seen labelled as Kamaguri 釜ぐり or 釜ぐり茶.

釜炒り茶 is then a pan-fired tea, in contrast with the usual process of steamed teas that make up the bulk of the production in Japan commonly. It's a process that originated in China, where it is still being used, and also used in Korean teas. Introduced through the North of Kyushu island, probably through the former Hizen province, it has remained a regional speciality. It was one of the main methods of processing tea before the invention and popularisation of the steaming method in Kyoto, which spread further out and became prevalent quickly. 

In contrast to other green teas, in Japan, leaves manufactured as Kamairicha are not rolled in needle shape but left to be curled and twisted. Giving the appearance of a lesser tea, but that is not the case. 

Tamaryokucha 玉緑茶 means ball or curly green tea. Includes two tea manufacturing processes, steam 蒸し製玉緑茶 or pan-firing 釜炒り製玉緑茶, can be seen labelled as Gurichaぐり茶 for the steamed version or Kamaguri 釜ぐり or 釜ぐり茶 for the pan-fired.

The pan-fired one is usually known as [[Kamairicha 釜炒り茶]] alone, adding to the possible confusion. While the steamed processed one is regarded simply as Tamaryokucha. The steamed version of [[Tamaryokucha 玉緑茶]] tried to simulate the Kamairicha process while improving the production volume and human labour costs. Together with certain developments around the early 1890s with Japanese tea exports, both versions remain.
![[Tamaryokucha 玉緑茶.png]]
Kamairicha (pan-fired method) can be produced in straight needle shape too, [[Kamanobicha 釜伸び茶]]. Meaning stretched or spread cauldron tea. 

## Production
At some point, Kamairicha production was present in many regions. Nowadays, it is found mainly in Kyushu, where it was introduced first from mainland China. It remained on the island as a local speciality after the invention raise of [[Sencha 煎茶]] and its more efficient and less labour-intensive production method.  

Production amounts are difficult to come across as some include steamed and pan-fired under the same volumes. There was also a data collection halt by the Ministry of Agriculture and Forestry on pan-fired Kamairicha in 1894. More on that later.

In 1967 a survey from the Agricultural and Forestry Statistics Association placed the national volume of Kamairicha at 0,5% of the total volume. With the volume production survey of 2021 from the Japanese Association of Tea Production, the amount of Kamairicha is at 0,3% (235t) and 2,27% (1720t) for Tamaryokucha. The total volume of tea produced was 75,579 tons.

https://datawrapper.dwcdn.net/P0BJB/5/
<iframe title="Kamairicha production volumes 2021" aria-label="Table" id="datawrapper-chart-P0BJB" src="https://datawrapper.dwcdn.net/P0BJB/5/" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="460" data-external="1"></iframe><script type="text/javascript">!function(){"use strict";window.addEventListener("message",(function(e){if(void 0!==e.data["datawrapper-height"]){var t=document.querySelectorAll("iframe");for(var a in e.data["datawrapper-height"])for(var r=0;r<t.length;r++){if(t[r].contentWindow===e.source)t[r].style.height=e.data["datawrapper-height"][a]+"px"}}}))}();
</script>

If we look at the total of both steamed and pan-fired, Kyushu is responsible for 92,7% of the volume produced. Some production is present [[Shizuoka 静岡]] due to historical reasons and a small part in [[Shimane 島根]].

## Styles of production

There are two distinct styles, the Ureshino Style 嬉野製, common in [[Saga 佐賀]] and [[Nagasaki 長崎]]. And the Aoyagi Style 青柳製, common in [[Kumamoto 熊本]] and [[Miyazaki 宮崎]]. The Ureshino Style presents a 45º inclination of the firing pan, while the Aoyagi is parallel to the floor.

Nowadays, production is done with machines using a mechanical pan or drum to stop oxidation. Some machines, or parts of production lines, in these factories are sencha-producing machines adapted for Kamairicha production. Some farms produce Sencha and Kamairicha, thus using or repurposing the available tools for the teas produced. 

After pan-firing, the leaves roll in a circular motion machine that presses them together and helps break the cellular structure of the tea. Traditional Kamairicha tea maintained the internal cellular structure of the leaves, so the flavour release was not as high as steamed teas. The addition of a rolling mat 床もみ many years ago was one of the main developments in the flavour release for pan-fired teas.

As a final step, there is another round of firing in a pan to develop the "KamaKa" (釜香), the smell of the pan, a roast aroma characteristic of the Kamairicha processed teas. This step can also be done with drum machines, although more indirectly, as they use hot air. Or with more traditional drying cabinets or rooms, some of these developments were tested and implemented to improve the drying process. Before the invention of more modern machinery and technology was available.

There was also a variation, now extinct, where the final drying was done in the sun or inside when the weather was unfavourable. It produced a lower quality beverage, considered one of the lowest grades and named Bancha in some regions. It was not like the current bancha, just a term to identify the grade of the tea. The term bancha could mean different things in different producing regions.

### Ureshino Style 嬉野製
#### Origins
The production of tea in Japan is said to have begun with monk Eisai when he returned from a pilgrimage in China, brought seeds and planted them in three sites, one of them was Mt.Sefuri 脊振山 in Saga, a natural division with the neighbouring prefecture Fukuoka.

As for the production in Ureshino, closer to the Nagasaki prefecture, production is said to have been started by Chinese (or Korean) immigrants that had a presence in the northern part of the island. In particular, Chinese potters that established their kilns in the regions began tea cultivation around 1440. At the time, pan-fired methods were already existent in China. Around the 1510s, a Chinese immigrant brought the metal cooking implement used to produce it, a 唐釜 (とうがま). Later this developed into the Ureshino style and the characteristic inclined pan.
The origin of tea production in Ureshino might have started at Mt.Fudosan 不動山, where a preserved large tea tree is present. Ureshino belonged to the former Hizen province that included both Nagasaki and Saga.

#### Processing
In this style, they use tilted pans at 45 degrees, 傾斜釜, in comparison with the flat-oriented pan of the Aoyagi style. The entire process took around 2,5 hours, including the initial kill-green roasting, rolling off the leaves (using a rolling mat and crushing the structure of the leaf for better flavour release, now achieved with rolling machines and applying pressure), drying of the moisture and then several roasting stages. A typical amount would start with 3-4 kg of fresh leaves, and the weight loss is around 35% in the initial steps.

#### Main attributes
The leaves present a deep green colour with yellow-brown tones due to the temperatures of the pan. The liquor is yellow-orange. The aroma is intense due to the pan-firing method, but the flavour is not overwhelming. The flavour release improves with several steepings compared to the more easily released steamed teas. The higher temperature of the water helps with the initial release of flavour. The cup results in a round and mellow brew with a particular aroma of pan-fired teas. As an initial recommendation, try 3gr per 100ml at 85º for 40 sec. Then adjust to any personal preference or particularities of the tea leaves themselves.

### Aoyagi Style 青柳製
#### Origins
The Aoyagi style developed in the [[Kumamoto 熊本]] and [[Miyazaki 宮崎]] regions. In particular, that began in Higo Province 肥後, the area that is nowadays [[Kumamoto 熊本]]. This production style was introduced in Kyushu from Korea during the invasions of the peninsula between 1592–1598. Captive potters, workers and engineers were brought to Japan by several daimyos, including Kato Kiyomasa, responsible for the expansion of the Kumamoto Castle between 1596-1607. Once construction concluded, and with the recovery of the relationships with Korea a few years later, the workers that wished to stay moved to 加勢群 かせむろ. 

These workers transmitted the Aoyagi method of production to the region. It could be the case that this method originated in China, found its place in Korea and later in Japan, presenting two different entry routes for the [[Pan-fired teas 釜炒り茶]] into Japan, both through Kyushu due to the island being the main entry point from both China and Korea. The Aoyagi method already being used before the Korean invasion is also theorised. 

#### Processing
The main difference is the use of a pan parallel to the floor. This pan had a deeper shape than the inclined one used in the Ureshino style. The weight loss seems to be a bit higher when this style is used, at around 40~50%. The entire process takes 1,5 hours, and the amount of raw leaves is about 3 kg.

#### Main attributes
Leaves have a green-bluish lustre, and the liquor colour is green, with less reddish tonality, compared to the Ureshino style. The shape of the leaves is elongated, and the aroma is more intensely present. The bluish colour of the tea leaves is a trait particular to the Aoyagi style. That emphasizes using more buds than leaf material and finishes the roasting at this deep green with a slightly blue hue. Looking at the characters used in the name Ao 青 means blue while Yagi 柳 means willow. It describes the characteristic colour of the tea leaves, and the second character for willow describes the elongated shape of the finished tea leaves.

### Sun-dried style 釜炒り日干茶
The sun-dried tea was produced similarly to the Ureshino or Aoyagi styles. The final drying was done by sun drying. This tea was considered one of the lowest tea grades available and categorized as [[Bancha 番茶]] in its producing regions.

The tea was spread out on the floor to dry under the sun and taken inside to dry if rain or bad weather was present. Similar to how [[Goishicha 碁石茶]] is put out to dry in the sun and taken inside in the evenings or bad weather conditions. The regions producing this tea included Kyushu, Shikoku and Chukoku. 

## Historical events

Due to the similarities in processing, all pan-fired teas fell under the same category. During the late Edo period (1603-1868), exports grew considerably, resulting in an increase in price and the growth in low-grade tea, including tea with twigs or not even made with tea leaves. In 1893 to maintain the reputation of Japanese tea, pan-fired tea was banned from export and excluded from the 1894 national statistics nationwide as well. The main reason behind this decision was the low quality of sun-dried pan-fired style tea and "fake tea" being exported. Because pan-fired tea was labelled under the same name, independently of the style or drying process, resulting in a complete banning on this style.

This event accelerated the shift to an already booming [[Steamed processed teas 蒸し製]] production, where Japanese tea production shifted to steamed sencha during the Meiji period (1868-1912). On the positive side, after the export ban, the government started controlling the production of pan-fired tea and new, improved drying methods were introduced to ensure the quality and reliability of the products.

The growing exports and banning of pan-fired tea in 1893, stimulated the development of a similar style of tea during the late Taisho and early Showa periods to lower the high labour cost while increasing production. The steamed variant of [[Tamaryokucha 玉緑茶]] was developed to be similar in shape to the pan-fired teas, with lower labour costs in production. It also could be exported to countries that imported pan-fired green tea from China with relative ease. The Soviet Union consumed green tea from China, and Japan exported this new style of tea there. 

It was at some point exported to North Africa, just after world war 1, due to other countries, mainly India, being unable to ship their products to foreign nations. And at the end of world war 2, with the help of countries like America and France in exchange for food and fuel. Soon after the war, the exports declined again with the rapid growth of the Japanese economy and countries like Taiwan and China making a re-appearance in the market. Japanese tea could not compete with products that tried to mimic Chinese pan-fired teas with the prices and volumes of these countries. A similar story to the one experienced with the efforts on black tea exports.

This steamed variant was developed in Shizuoka and produced in large quantities in the Izu region. And was mainly traded through the port of Shimizu, a key port for foreign trade before and after the war and close to the Makinohara plateau, which would eventually become the largest tea-producing area in Japan.  

---
# References

Simona. “Kamairicha (釜炒り茶).” _Global Japanese Tea Association_, 30 June 2022, [https://gjtea.org/kamairicha/](https://gjtea.org/kamairicha/).

“釜炒り茶ってこんなお茶。Pan-fired tea is this kind of tea.” _釜炒り茶dっとこむ。Kamairicha dot com._, [http://www.kamairicha.com/whatskamacha/index.html](http://www.kamairicha.com/whatskamacha/index.html).

Caicedo, Ricardo. “Kamairicha.” _My Japanese Green Tea_, [https://www.myjapanesegreentea.com/kamairicha](https://www.myjapanesegreentea.com/kamairicha).

全国茶生産団体連合会。Japanese Association of Tea Production. _種類別の主な茶産地、令和3年茶種別生産実績。Major Tea Production Areas by Type and Production Results by Tea Type in 2021._ 全国茶生産団体連合会。Japanese Association of Tea Production., [https://www.zennoh.or.jp/bu/nousan/tea/dekiru03.htm](https://www.zennoh.or.jp/bu/nousan/tea/dekiru03.htm).

“日本のお茶のふるさと佐賀。 Saga, the home of Japanese tea.” _佐賀県ふるさと歴史物語。Saga Prefecture Historical Tales._, 教育委員会事務局　学校教育課, 2016, pp. 46–49, [https://www.pref.saga.lg.jp/kiji00346510/3_46510_13_201634151258.pdf](https://www.pref.saga.lg.jp/kiji00346510/3_46510_13_201634151258.pdf).

Sakamoto, Takayoshi. “Japanese Kamairicha (Pan Fired Tea).” _Chagyo Kenkyu Hokoku (Tea Research Journal)_, vol. 2018, no. 125, June 2018, pp. 1–6, [https://doi.org/10.5979/cha.2018.125_1](https://doi.org/10.5979/cha.2018.125_1).

煎茶堂東京編集部. “玉緑茶ってどんなお茶？勾玉状の風変わりな日本茶の魅力。What kind of tea is Tamaryokucha? The charm of this quirky, slope-shaped Japanese tea.” 煎茶堂東京, 17 Nov. 2020, [https://shop.senchado.jp/blogs/ocha/20201117_350](https://shop.senchado.jp/blogs/ocha/20201117_350).

煎茶堂東京編集部. “釜炒り茶ってどんなお茶？香り豊かで希少な釜炒り茶の魅力に迫る。What kind of tea is kamairicha? We take a closer look at the charm of this rare and aromatic tea.” 煎茶堂東京, 11 Jan. 2020, [https://shop.senchado.jp/blogs/ocha/20201101_356](https://shop.senchado.jp/blogs/ocha/20201101_356).

Florent-. “The Adventures of Japanese Tea Exports to Muslim Markets (1918-1959).” _Japanese Tea Sommelier_, 15 Apr. 2012, [https://japaneseteasommelier.wordpress.com/2012/04/15/the-adventures-of-japanese-tea-exports-to-muslim-markets-1918-1959/](https://japaneseteasommelier.wordpress.com/2012/04/15/the-adventures-of-japanese-tea-exports-to-muslim-markets-1918-1959/).

Florent-. “When Japanese Tea Shone in the World: The Development and Export of Sencha (1853-1918).” _Japanese Tea Sommelier_, 14 Apr. 2012, [https://japaneseteasommelier.wordpress.com/2012/04/14/when-japanese-tea-shone-in-the-world-the-development-and-export-of-sencha-1853-1918/](https://japaneseteasommelier.wordpress.com/2012/04/14/when-japanese-tea-shone-in-the-world-the-development-and-export-of-sencha-1853-1918/).

“Higo Province.” _Wikipedia_, 28 Mar. 2012. _Wikipedia_, [https://en.wikipedia.org/w/index.php?title=Higo_Province&oldid=484435186](https://en.wikipedia.org/w/index.php?title=Higo_Province&oldid=484435186).

---
Tags:
Type: #idea
Zettelkasten UID: 202208071940
