---
title: Asatsuyu あさつゆ
tags: cultivar tea
date: 2023-02-09
hour: 11:23
---
Status: 🌱
# Asatsuyu あさつゆ
## Genealogy

Kyoto Uji indigenous Zairai tea tree seed

## History
Asatsuyu became a registered cultivar in 1953, in the initial tea cultivar registrations under the Agriculture and Forestry Certified Cultivars (農林認定品種), with registration number 2. Registered after [[Benihomare べにほまれ]], and for use as a [[Sencha 煎茶]] cultivar. 

The selection of this cultivar was from Uji [[Zairai 在来種]] seedlings by the agricultural bureau tea experiment station in Nishigahara, Tokyo, established in 1896 and part of the old Ministry of Agriculture and Commerce 農商務省 (existed 1881-1925)​. 

In 1921 it transferred to a different tea research facility established in 1919 in its current location, that later became the modern Tea Research Institute Kanaya (茶業研究所金谷). These selected seedlings started testings in 1940 under the name U14(国茶U14号).

In 1925 the Ministry of Agriculture and Commerce 農商務省 split into the Ministry of Agriculture and Forestry (1925-1978)​ 農林省, the predecessor of the current Ministry of Agriculture, Forestry and Fisheries (MAFF), and the Ministry of Commerce. 

Now, the cultivar registration falls under the Kanaya tea research facility in Shizuoka, part of the Institute of Fruit Tree and Tea Science, NARO (NIFTS), under the umbrella of MAFF.

This cultivar is commonly known as "natural Gyokuro" (天然玉露) due to its bright green colour and sweet bean taste without the need for shading. 

## Characteristics
Compared to the standard cultivar, [[Yabukita やぶきた]], it is an early shooting cultivar, up to 6 days earlier for harvesting. Breeders noted its initial poor root development. Initial propagation used [layering](https://en.wikipedia.org/wiki/Layering?oldid=478478440) methods.

It is relatively resistant to cold but not so resistant to frost damage, especially as it is an early shooter, damaging the new buds leading to the first harvest, and recovery of the plant after frost damage is also slow. Asatsuyu is a cultivar usually cultivated in more warm and temperate regions where the risk of frost is low, which in the case of this particular cultivar is Kagoshima.

As of 2012, it made up 1,2% of the total production in Japan, with around 500ha using this cultivar. With 5% of cultivation in Kagoshima but no significant amounts in other producing regions.

The average harvest quantity is lower than Yabukita, with smaller buds and more delicate leaves. Extra care in the post-harvest processing of the leaf material is needed. It also requires adequate field management to handle the plants' energy, as after the first harvest can decay considerably.

As its nickname describes, it has some characteristics usually found in shaded teas like [[Gyokuro 玉露茶]]. It showcases a bright, lush green colour in its leaves and liquor. Compared with Yabukita, it has a mellower aroma and a rich, balanced umami presence.

Asatsuyu has been crossbred successfully into other important cultivars like: [[Tsuyu Hikari　梅雨光 つゆひかり]], [[Yutakamidori ゆたかみどり]] and [[Saemidori さえみどり]]. As with Yabukita, it shares a weakness against anthracnose inherited by most of the descendants of these two cultivars. And in consequence, a common pest found in most tea gardens that use cultivars suited for Sencha. 

7 out of 10 most common cultivars descend from Yabukita or Asatsuyu. This lack of genetic diversity presents a challenge, as the overall resistance to pests and disease remains low. That means that most of the cultivated tea is more vulnerable to these pests and diseases, further relying on the use of pesticides or other chemical products. 



---
# References

Caicedo, Ricardo. “Asatsuyu.” _My Japanese Green Tea_, 10 Dec. 2013, https://www.myjapanesegreentea.com/the-asatsuyu-tea-cultivar.

Caicedo, Ricardo . “Japanese Tea Cultivar List.” _My Japanese Green Tea_, 8 Oct. 2013, https://www.myjapanesegreentea.com/japanese-tea-cultivar-list.

Florent. “The Japanese Tea Cultivars.” _Japanese Tea Sommelier_, 22 Aug. 2022, https://japaneseteasommelier.wordpress.com/2022/08/22/the-japanese-tea-cultivars/.

Florent -. “Senchas from ‘Nord-Kantô’, First Part: Sashima.” _Japanese Tea Sommelier_, 22 Oct. 2020, https://japaneseteasommelier.wordpress.com/2020/10/22/senchas-from-nord-kanto-first-part-sashima/.

Pandey, Abhay K., et al. “How the Global Tea Industry Copes With Fungal Diseases – Challenges and Opportunities.” _Plant Disease_, vol. 105, no. 7, July 2021, pp. 1868–79, https://doi.org/10.1094/pdis-09-20-1945-fe.

Wikipedia. “Layering.” _Wikipedia_, 13 Feb. 2023, https://en.wikipedia.org/wiki/Layering.

勝尾清. _最近の茶樹育種の発展と今後 (2) - Recent Development and Future of Tea Tree Breeding (2)_. 農業技術協會 - Agricultural Technology Association, Dec. 1971, p. 2, https://agriknowledge.affrc.go.jp/RN/2030041030.pdf.

農林水産省- Ministry of Agriculture, Forestry and Fisheries (MAFF). _新品種・新技術の開発・保護・普及の方針 茶 - Policy for Development, Protection and Dissemination of New Varieties and Technologies_. https://www.maff.go.jp/j/kanbo/kihyo03/gityo/tuyomi/pdf/05-02tya.pdf.

農林水産省調 - Survey by the Ministry of Agriculture, Forestry and Fisheries. _茶園面積の品種別割合 - Percentage of Tea Plantation Area by Variety_. 2012, https://www.google.com/url?client=internal-element-cse&cx=015840603635610229114:d5nyfxhiq78&q=https://www.maff.go.jp/j/wpaper/w_maff/h25/h25_h/trend/part1/other/P135_d2_4_15.xls&sa=U&ved=2ahUKEwj0k7KY35X9AhUpBxAIHfjsBzsQFnoECAkQAg&usg=AOvVaw0RthQLQ0BxN0tuOdhXO5z_.  This one is a download of an excel file i found on the MAFF website, not accessible in any other way I could find.

農林省 - Ministry of Agriculture and Forestry. _茶の品種登録と命名 - Registration and Naming of Tea Varieties_. Oct. 1953, p. 1, https://www.jstage.jst.go.jp/article/cha1953/1953/2/1953_2_95/_pdf/-char/en.

農林省茶業試験場. _あさつゆ(品種解説シリーズ) - Asatsuyu (Explanation of Variety Series)_. 農林水産技術会議事務局 - Secretariat of Agriculture, Forestry and Fisheries Technology Council, Mar. 1968, p. 3, https://agriknowledge.affrc.go.jp/RN/2039015387.pdf.

農研機構 - NARO. “茶の環境にやさしい栽培技術、品質評価技術習得研修 - Training to Acquire Environmentally Friendly Cultivation and Quality Evaluation Techniques for Tea.” _農研機構 - Naro_, 農研機構 - NARO, Aug. 2007, pp. 1–3, https://www.naro.go.jp/training/files/2007-8material.pdf.

---. “野菜茶業研究所:農業技術研修生 (茶業研修) 関係情報 - Vegetable Tea Industry Research Institute: Agricultural Technology Trainee (Tea Industry Training) Related Information.” _農研機構 - Naro_, 農研機構 - NARO, Aug. 2007, pp. 1–3, https://www.naro.affrc.go.jp/archive/vegetea/introduction/kanaya/chagyo_kensyu_joho/index.html#enkaku.

静岡県茶業会議所. 茶の品種. 2003. 2nd ed., 静岡県茶業会議所, 2019, https://shizuoka-cha.com/index.php/books.

---
Tags:
Type: #idea
Zettelkasten UID: 202302091123
